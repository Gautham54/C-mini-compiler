#include<stdio.h>
void main()
{   int n=10,i;
   int i;
    for(i=0;i<n;i++)
    {  printf("%d ",i);
       int d=5;
      // int i;
       while(d>0)
       {  printf("%d ",d);
          d--;
       }
       
    }

}

