#include<stdio.h>

void main()
{  int a=3,i;
   for(i=0;i<a;i++)
   { printf("%d ",i);

   }
    return 0;
}