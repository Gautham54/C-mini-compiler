#include<stdio.h>
void main()
{  int b=5,i;
   while(i<6)
   {  int a;

   }
   a=78;

}