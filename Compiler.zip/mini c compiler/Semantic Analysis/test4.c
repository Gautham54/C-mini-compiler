#include<stdio.h>
int main()
{    int i=0;
      int n=10;
      char i='a';
      while(i<n)
      {    if(i%2==0)
             { 
                printf("%d ",i);
             }

      }

}

