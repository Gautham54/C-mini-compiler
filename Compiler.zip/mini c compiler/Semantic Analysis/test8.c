#include<stdio.h>
int main()
{  int b=2;
   int i=0,a;
   a=b*2;
   while(i<b)
   {  b=b/2;
      i++;
   }
}
