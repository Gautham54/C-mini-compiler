#include<stdio.h>
int func(int a)
{ 
   return a*2;

}
void main()
{   int n=10,i=0;
    for(i=0;i<n;i++)
    {   func();

    }

}