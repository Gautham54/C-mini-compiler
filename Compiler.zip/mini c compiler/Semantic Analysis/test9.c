#include<stdio.h>
int func()
{  int for;

}
void main()
{  int a=4;
   int i=0;
   while(i<4)
   {  i++;

   }

}