#include<stdio.h>
void main()
{   int b;
    char a;
    b=3;
    printf("%d",a+b);
    printf("%d",a-b);
    printf("%d",a*b);
    printf("%d",a++);

}

