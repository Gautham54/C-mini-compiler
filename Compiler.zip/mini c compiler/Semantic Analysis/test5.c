#include<stdio.h>
void main()
{ int a=2;
  char x='a';
  unsigned int b=4;
  long int c=5;
  int f;
  f=a+x;
  printf("%d",f);
  unsigned long int d=4;
  printf("%d ",a+b);
  printf("%d ",a-b);
  int i;
  
  for(i=0;i<10;i++)
  {  int k=0;
     while(k<3)
     { printf("%d ",k);
       k++;
     }

  }
   
}