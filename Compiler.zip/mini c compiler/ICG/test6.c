

#include<stdio.h>

int main() {
    char @hello;
    @hello = 'c';
}