// Implicit Error that our Language doesn't support

#include<stdio.h>

int main() {
    char @hello;
    @hello = 'c';
}