//for loop
//continue
//while loop
//do while loop

#include<stdio.h>

int main()
{
    int a=0;
    for (a = 0; a < 10; a++)
        {
        	printf("H1");
        }
    
    while(a>0) {
        a--;
    }

    while(a<10)
    {
        a++;
    }
}