#include<stdio.h>

struct node
{
	int a;
}

int main()
{
	int a = 5;
}

