#include<stdio.h>

int main()
{
	char c;
	'c' = 'x';
}

