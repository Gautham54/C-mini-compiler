#include<stdio.h>

int main()
{
	char s;
	printf("hai");
}

