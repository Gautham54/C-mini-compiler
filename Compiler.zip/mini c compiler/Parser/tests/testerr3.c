#include<stdio.h>

int main()
{
	while:
	{
		printf("hai");
	}
}

