#include<stdio.h>
#include<string.h>
int main()
{
    char str[100];
    int a[26]={0};
    int b[26]={0};
    int i=0,j=0,k=0,p=0,t=0,l=0,z=0,count=0,q;
    scanf("%d",&q);
    for(i=0;i<q;i++)
    {
        scanf("%s",str);
        for(j=0;j<strlen(str);j++)
        {
            //printf("q");
            for(k=1;k<strlen(str);k++)
            {
                //printf("q1");
                for(t=j;t<=j+k-1 && t<strlen(str);t++)
                {
                    // printf("q2");
                    a[str[t]-97]++;
                    //printf("%d\n",t);
                }
                    for(p=j+1;p<strlen(str);p++)
                    {
                        // printf("q4");
                        for(z=p;z<=p+k-1 && z<strlen(str);z++)
                        {
                            // printf("q5");
                                b[str[q]-97]++;
                        }
                        if(strcmp(a,b)==0)
                        {
                            count++;
                            //printf(" %d\n",count);
                        }
                        for(l=0;l<26;l++)
                        {
                            b[l]=0;
                        }
                    }
                for(l=0;l<26;l++)
                {
                    a[l]=0;
                }
            }
        }
        printf("%d \n",count);
        count=0;
    }
}
